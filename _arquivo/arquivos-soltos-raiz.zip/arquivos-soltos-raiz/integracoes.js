// Integração real com o Mercado Livre: conectar via OAuth (PKCE), consultar
// status da conexão e disparar sincronização de pedidos. Não implementa
// Shopee nem nenhum outro marketplace nesta etapa.
const express = require('express');
const pool = require('../db/pool');
const { encrypt } = require('../lib/crypto');
const { generateState, generatePkce } = require('../lib/pkce');
const ml = require('../lib/mercadolivre');
const {
  sincronizarConta,
  importarPedidoPorNotificacao,
  iniciarOuRetomarSyncHistorico,
  buscarUltimoSyncHistorico,
  processarSyncHistorico,
} = require('../lib/mlSync');
const { obterStatusSincronizacao } = require('../lib/syncScheduler');

const router = express.Router();

function getRedirectUri(req) {
  return process.env.ML_REDIRECT_URI || `${req.protocol}://${req.get('host')}/api/integracoes/mercadolivre/callback`;
}

function mlConfigurado() {
  return Boolean(process.env.ML_CLIENT_ID && process.env.ML_CLIENT_SECRET && process.env.ML_TOKEN_KEY);
}

function serializeConta(row) {
  return {
    id: row.id,
    empresaId: row.empresa_id,
    mlUserId: String(row.ml_user_id),
    nickname: row.nickname,
    email: row.email,
    siteId: row.site_id,
    status: row.status,
    ultimoErro: row.ultimo_erro,
    tokenExpiraEm: row.token_expires_at,
    ultimaSincronizacaoEm: row.ultima_sincronizacao_em,
    criadoEm: row.created_at,
  };
}

// GET /api/integracoes/mercadolivre/config-status — se o app do ML já foi configurado no servidor
router.get('/config-status', (req, res) => {
  res.json({ configurado: mlConfigurado() });
});

// GET /api/integracoes/mercadolivre — lista contas conectadas (opcionalmente por empresa)
router.get('/', async (req, res, next) => {
  try {
    const { empresaId } = req.query;
    const where = empresaId ? 'WHERE empresa_id = $1' : '';
    const params = empresaId ? [empresaId] : [];
    const { rows } = await pool.query(`SELECT * FROM ml_contas ${where} ORDER BY created_at DESC`, params);
    res.json({ contas: rows.map(serializeConta) });
  } catch (err) { next(err); }
});

// GET /api/integracoes/mercadolivre/status-automatico — estado (em memória
// do servidor) da sincronização automática de 1 em 1 minuto (ver
// lib/syncScheduler.js) — usado só pelo indicador discreto "Sincronizado há
// Xs" do header do ERP. Não confundir com o status por conta (ultimo_erro/
// ultima_sincronizacao_em de ml_contas, já usado na tela Marketplaces): este
// aqui é o "batimento cardíaco" do job em si, independente de qual empresa
// está selecionada no filtro.
router.get('/status-automatico', (req, res) => {
  const s = obterStatusSincronizacao();
  res.json({
    ativo: s.ativo,
    intervaloSegundos: Math.round(s.intervaloMs / 1000),
    reconciliacaoDias: s.reconciliacaoDias,
    emExecucao: s.emExecucao,
    ultimaExecucaoEm: s.ultimaExecucaoEm,
    ultimoCicloOk: s.ultimoCicloOk,
    contasProcessadas: s.contasProcessadas,
    contasComErro: s.contasComErro,
    ultimoErroGeral: s.ultimoErroGeral,
  });
});

// GET /api/integracoes/mercadolivre/conectar?empresaId=ID — inicia o OAuth (redireciona pro Mercado Livre)
router.get('/conectar', async (req, res) => {
  const { empresaId } = req.query;
  const redirectComErro = (msg) => res.redirect('/#marketplaces?ml=error&msg=' + encodeURIComponent(msg));

  if (!mlConfigurado()) {
    return redirectComErro('Integração com o Mercado Livre ainda não foi configurada neste ambiente (faltam credenciais do app).');
  }
  if (!empresaId) {
    return redirectComErro('Selecione uma empresa antes de conectar o Mercado Livre.');
  }

  try {
    const { rows } = await pool.query('SELECT id, ativo FROM empresas WHERE id = $1', [empresaId]);
    if (!rows.length) return redirectComErro('Empresa não encontrada.');
    if (!rows[0].ativo) return redirectComErro('Só é possível conectar o Mercado Livre a uma empresa ativa.');

    const state = generateState();
    const { verifier, challenge } = generatePkce();
    await pool.query(
      'INSERT INTO ml_oauth_states (state, empresa_id, code_verifier) VALUES ($1,$2,$3)',
      [state, empresaId, verifier]
    );

    const url = ml.buildAuthorizationUrl({
      clientId: process.env.ML_CLIENT_ID,
      redirectUri: getRedirectUri(req),
      state,
      codeChallenge: challenge,
    });
    res.redirect(url);
  } catch (err) {
    console.error('[integracoes/mercadolivre/conectar]', err);
    redirectComErro('Não foi possível iniciar a conexão com o Mercado Livre.');
  }
});

// GET /api/integracoes/mercadolivre/callback — volta do Mercado Livre com ?code&state
router.get('/callback', async (req, res) => {
  const { code, state, error, error_description: errorDescription } = req.query;
  const redirectComErro = (msg) => res.redirect('/#marketplaces?ml=error&msg=' + encodeURIComponent(msg));

  if (error) {
    return redirectComErro(errorDescription || 'Autorização cancelada ou negada no Mercado Livre.');
  }
  if (!code || !state) {
    return redirectComErro('Retorno inválido do Mercado Livre.');
  }

  try {
    const { rows: stateRows } = await pool.query('SELECT * FROM ml_oauth_states WHERE state = $1', [state]);
    if (!stateRows.length) return redirectComErro('Sessão de conexão expirada ou inválida. Tente conectar novamente.');
    const { empresa_id: empresaId, code_verifier: codeVerifier } = stateRows[0];
    await pool.query('DELETE FROM ml_oauth_states WHERE state = $1', [state]); // uso único

    const tokenData = await ml.exchangeCodeForToken({
      clientId: process.env.ML_CLIENT_ID,
      clientSecret: process.env.ML_CLIENT_SECRET,
      code,
      redirectUri: getRedirectUri(req),
      codeVerifier,
    });

    const me = await ml.apiGet('/users/me', tokenData.access_token);

    const { rows } = await pool.query(
      `INSERT INTO ml_contas (
         empresa_id, ml_user_id, nickname, email, site_id,
         access_token_enc, refresh_token_enc, token_expires_at, escopo_oauth, status, ultimo_erro, updated_at
       ) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,'ativa',NULL, now())
       ON CONFLICT (ml_user_id) DO UPDATE SET
         empresa_id = EXCLUDED.empresa_id,
         nickname = EXCLUDED.nickname,
         email = EXCLUDED.email,
         site_id = EXCLUDED.site_id,
         access_token_enc = EXCLUDED.access_token_enc,
         refresh_token_enc = EXCLUDED.refresh_token_enc,
         token_expires_at = EXCLUDED.token_expires_at,
         escopo_oauth = EXCLUDED.escopo_oauth,
         status = 'ativa',
         ultimo_erro = NULL,
         updated_at = now()
       RETURNING id`,
      [
        empresaId,
        me.id,
        me.nickname || null,
        me.email || null,
        me.site_id || null,
        encrypt(tokenData.access_token),
        encrypt(tokenData.refresh_token),
        new Date(Date.now() + tokenData.expires_in * 1000),
        // Guardado só pra diagnóstico (IA de Promoções, ver lib/mlPermissoes.js)
        // — o texto exato que o Mercado Livre devolveu, nunca inventado.
        // .slice() de segurança: a coluna já é TEXT (sem limite), mas um
        // valor absurdamente grande nunca deveria travar a conexão da conta
        // por causa de um campo puramente informativo.
        tokenData.scope ? String(tokenData.scope).slice(0, 2000) : null,
      ]
    );

    res.redirect('/#marketplaces?ml=success&conta=' + rows[0].id);
  } catch (err) {
    console.error('[integracoes/mercadolivre/callback]', err);
    redirectComErro('Não foi possível concluir a conexão com o Mercado Livre.');
  }
});

// POST /api/integracoes/mercadolivre/webhook — notificação em tempo real do
// Mercado Livre (tópico orders_v2, configurado no painel do app do ML).
// A própria documentação do Mercado Livre pede pra confirmar o recebimento
// com HTTP 200 o mais rápido possível, e só DEPOIS buscar o pedido completo
// na API — por isso a resposta é enviada antes de qualquer processamento.
router.post('/webhook', async (req, res) => {
  res.sendStatus(200);

  try {
    const body = req.body || {};
    const { resource, topic, user_id: mlUserId, application_id: applicationId } = body;

    if (topic !== 'orders_v2' || !resource || !mlUserId) return; // só processamos notificação de pedido

    if (process.env.ML_CLIENT_ID && String(applicationId) !== String(process.env.ML_CLIENT_ID)) {
      console.warn('[ml webhook] application_id da notificação não confere com ML_CLIENT_ID — ignorada.');
      return;
    }

    const match = /\/orders\/(\d+)/.exec(resource);
    if (!match) return;
    const orderId = match[1];

    await importarPedidoPorNotificacao(mlUserId, orderId);
  } catch (err) {
    // Nunca propaga erro pro Mercado Livre (a resposta 200 já foi enviada) —
    // só registra, pra não perder o rastro se um pedido falhar ao importar
    // por notificação. A próxima sincronização manual/periódica cobre o que
    // passar batido aqui.
    console.error('[ml webhook] falha ao processar notificação:', err.message);
  }
});

// POST /api/integracoes/mercadolivre/:id/sincronizar — importa/atualiza os pedidos dessa conta
router.post('/:id/sincronizar', async (req, res, next) => {
  try {
    const resultado = await sincronizarConta(req.params.id);
    res.json(resultado);
  } catch (err) {
    if (err.status) return res.status(err.status).json({ error: err.message });
    next(err);
  }
});

const DATA_ISO_REGEX = /^\d{4}-\d{2}-\d{2}$/;

// Colunas DATE voltam do driver como objeto Date — normaliza pra
// 'YYYY-MM-DD' na resposta da API (mais simples de ler do que um
// timestamp ISO completo pra um campo que é só data).
function paraDataStr(v) {
  if (v === null || v === undefined) return null;
  if (typeof v === 'string') return v.slice(0, 10);
  return new Date(v).toISOString().slice(0, 10);
}

function serializeSyncHistorico(row) {
  if (!row) return null;
  return {
    id: row.id,
    contaMlId: row.conta_ml_id,
    desde: paraDataStr(row.desde),
    ateAlvo: paraDataStr(row.ate_alvo),
    status: row.status,
    janelaConcluidaAte: paraDataStr(row.janela_concluida_ate),
    totalEncontrados: row.total_encontrados,
    totalImportados: row.total_importados,
    erros: row.erros || [],
    iniciadoEm: row.iniciado_em,
    atualizadoEm: row.atualizado_em,
    finalizadoEm: row.finalizado_em,
  };
}

// POST /api/integracoes/mercadolivre/:id/sincronizar-historico — importa TODOS
// os pedidos desde uma data (body: { desde: 'YYYY-MM-DD' }, padrão 2026-07-01).
// Diferente de /sincronizar (só últimos 30 dias). Responde logo com o status
// inicial e continua em segundo plano (pode levar bastante tempo) — consultar
// o progresso em GET .../sincronizar-historico/status.
router.post('/:id/sincronizar-historico', async (req, res, next) => {
  try {
    const desde = (req.body && req.body.desde) || '2026-07-01';
    if (!DATA_ISO_REGEX.test(desde)) {
      return res.status(400).json({ error: 'Parâmetro "desde" precisa estar no formato YYYY-MM-DD.' });
    }

    const execucaoInicial = await iniciarOuRetomarSyncHistorico(req.params.id, desde);
    res.json({
      execucao: serializeSyncHistorico(execucaoInicial),
      aviso: 'Sincronização histórica iniciada em segundo plano — pode levar bastante tempo. Consulte o progresso em GET /api/integracoes/mercadolivre/:id/sincronizar-historico/status?desde=' + desde,
    });

    processarSyncHistorico(req.params.id, desde).catch((err) => {
      console.error('[sincronizar-historico] falhou:', err.message);
    });
  } catch (err) {
    if (err.status) return res.status(err.status).json({ error: err.message });
    next(err);
  }
});

// GET /api/integracoes/mercadolivre/:id/sincronizar-historico/status?desde=YYYY-MM-DD
router.get('/:id/sincronizar-historico/status', async (req, res, next) => {
  try {
    const desde = req.query.desde || '2026-07-01';
    if (!DATA_ISO_REGEX.test(desde)) {
      return res.status(400).json({ error: 'Parâmetro "desde" precisa estar no formato YYYY-MM-DD.' });
    }
    const execucao = await buscarUltimoSyncHistorico(req.params.id, desde);
    res.json({ execucao: serializeSyncHistorico(execucao) });
  } catch (err) { next(err); }
});

module.exports = router;
