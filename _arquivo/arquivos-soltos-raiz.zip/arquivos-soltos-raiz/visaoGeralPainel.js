// Visão Geral — blocos "Evolução diária / Por marketplace", "Fluxo de
// Caixa / Conexões & Empresas" e "Alertas & IA", ativados em 26/08/2026
// (pedido do usuário, em 3 passos — ver docs/02-decisoes.md e
// docs/04-alteracoes.md).
//
// Regras centrais do usuário, repetidas aqui de propósito:
//   1) NUNCA inventar dado — quando algo não pode ser calculado com certeza
//      (custo faltando, saldo bancário não cadastrado, API sem retorno),
//      o campo vem `null` com um motivo, nunca um número estimado.
//   2) NUNCA criar um cálculo financeiro diferente do que Visão Geral,
//      Pedidos, Financeiro e Relatórios já usam. Por isso este arquivo não
//      soma nada com fórmula própria — só reaproveita
//      lib/relatorioVendas.js (buscarPedidosDoPeriodo/resumirPeriodo/
//      buscarItensDoPeriodo — a MESMA fonte única de sempre),
//      lib/contasPagar.js, lib/contasReceber.js e lib/recebimentosMl.js,
//      além das tabelas ml_contas/ml_estoque_itens/empresas já existentes,
//      só filtrando/agrupando o que elas já calculam.
//   3) Empresa e período respeitam SEMPRE o filtro do header — nenhum
//      destes blocos tem filtro próprio.
const pool = require('../db/pool');
const { calcularPeriodo, periodoParaDatasBRT } = require('./periodo');
const { buscarPedidosDoPeriodo, resumirPeriodo, buscarItensDoPeriodo } = require('./relatorioVendas');
// Período anterior equivalente (20/09/2026, pedido explícito do usuário:
// "em visão geral quero colocar tudo que for possível... principalmente se
// o faturamento está caindo ou aumentando, comparado ao mês passado") —
// reaproveita EXATAMENTE a mesma definição já usada em Performance de
// Anúncios/Visitas e Conversão (ver lib/periodoComparacao.js: janela de
// MESMA DURAÇÃO imediatamente anterior ao período selecionado), nunca uma
// segunda definição de "período anterior" só pra esta tela.
const { periodoAnteriorEquivalente } = require('./periodoComparacao');
const { resumoContasPagar } = require('./contasPagar');
const { resumoContasReceber } = require('./contasReceber');
const { elegivel, serializeRecebimento } = require('./recebimentosMl');
const { round2 } = require('./resultadoVenda');
// Saldo bancário consolidado (31/08/2026) — reaproveita EXATAMENTE
// lib/contasBancarias.js#saldoConsolidado, a mesma função já usada pela tela
// Contas Bancárias e por lib/fluxoCaixa.js (tela Fluxo de Caixa). Nenhuma
// fórmula nova: antes desta etapa o ERP realmente não tinha saldo bancário
// cadastrado, então este bloco sempre respondia null — agora que existe
// (ver "saldo bancário automático via extrato"), o resumo abaixo passa a
// mostrar o valor real quando disponível, em vez de manter uma afirmação
// que deixou de ser verdade.
const { saldoConsolidado } = require('./contasBancarias');
// Radar da IA (25/08/2026) — leitura só (SELECT) do que o ciclo periódico
// já persistiu em segundo plano (ver lib/ia/radar.js/radarScheduler.js).
// Puramente ADITIVO: nenhuma regra/alerta já existente neste arquivo foi
// alterada — o campo `radar` é só mais uma chave no retorno de
// painelVisaoGeral, pro painel "Alertas & IA" mostrar os dois lados.
//
// require() feito DENTRO da função (lazy), não aqui no topo do arquivo, de
// propósito: lib/ia/radar.js -> lib/ia/radarNegocio.js -> este arquivo (pra
// reusar resumoRecebimentos/fluxoDeCaixa) fecha uma dependência circular
// com este módulo. Um require() no topo pegaria os exports de radar.js
// ainda incompletos nesse ciclo (obterRadarParaEmpresa viraria undefined,
// silenciosamente). Adiar o require pra dentro da função evita isso: por
// essa altura (execução em runtime, não em tempo de carregar módulos)
// todos os módulos já terminaram de carregar.

// "Muito baixo" — um limiar simples e declarado (não é previsão de demanda,
// é só o ponto de partida da central de alertas pedida pelo usuário:
// "não precisa criar ainda uma IA complexa"). Documentado em
// docs/02-decisoes.md — pode virar configurável numa etapa futura.
const ESTOQUE_BAIXO_LIMITE = 5;

function formatMoney(v) {
  return 'R$ ' + Number(v).toLocaleString('pt-BR', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
}

// ---------------- Por marketplace ----------------
// Até 14/09/2026, todo pedido vinha de ml_pedidos e o canal era sempre
// "Mercado Livre" (hardcoded). Desde a união com a Shopee em
// lib/relatorioVendas.js (buscarPedidosDoPeriodo agora traz `marketplace`
// já identificado em cada pedido — 'mercado_livre' | 'shopee'), esta função
// só lê esse campo — exatamente a extensão sem alterar mais nada desta
// tela já prevista no comentário original (pedido explícito do usuário:
// "quando houver outras integrações, elas devem entrar automaticamente").
function identificarCanal(pedido) {
  if (pedido.marketplace === 'shopee') return 'Shopee';
  // Venda de Balcão (22/09/2026) — 3º canal, mesmo espírito da extensão da
  // Shopee acima: sem esta branch explícita, toda venda de balcão cairia no
  // else e seria contada como "Mercado Livre" no painel "Vendas por
  // Marketplace" — dado errado, nunca só um rótulo feio.
  if (pedido.marketplace === 'balcao') return 'Venda no balcão';
  return 'Mercado Livre';
}

function porCanal(pedidos) {
  // MESMA função (resumirPeriodo) usada em Visão Geral/Pedidos/Financeiro/
  // Relatórios — nunca uma soma nova. Chamada uma vez pro total geral, e de
  // novo por canal (mesma ideia já usada em relatoriosAgregados.relatorioMarketplaces,
  // só que agrupando por canal em vez de por loja).
  const resumoGeral = resumirPeriodo(pedidos);
  const totalFaturamento = resumoGeral.faturamento.valor;

  const naoCancelados = pedidos.filter((p) => !p.cancelado);
  const grupos = new Map();
  naoCancelados.forEach((p) => {
    const canal = identificarCanal(p);
    if (!grupos.has(canal)) grupos.set(canal, []);
    grupos.get(canal).push(p);
  });

  const linhas = [...grupos.entries()].map(([canal, pedidosDoCanal]) => {
    const resumo = resumirPeriodo(pedidosDoCanal);
    const participacaoPercentual = (totalFaturamento !== null && totalFaturamento !== 0 && resumo.faturamento.valor !== null)
      ? round2((resumo.faturamento.valor / totalFaturamento) * 100)
      : null;
    return { canal, qtdPedidos: resumo.qtdPedidos, faturamento: resumo.faturamento, participacaoPercentual };
  }).sort((a, b) => (b.faturamento.valor || 0) - (a.faturamento.valor || 0));

  // 26/09/2026 — devoluções confirmadas do período (ver
  // lib/relatorioVendas.js#resumirPeriodo), pra tela poder mostrar "oque é
  // devolução e oque é cancelamento" separado, sem misturar os dois números
  // (cancelados já vem embutido dentro de resumoGeral, mas nunca exposto
  // aqui antes — devoluções, igual cancelamento, NUNCA entram em
  // totalFaturamento acima).
  return { linhas, totalFaturamento, devolucoes: resumoGeral.devolucoes, cancelados: resumoGeral.cancelados };
}

// ---------------- Evolução do faturamento vs. período anterior ----------------
// 20/09/2026, pedido explícito do usuário: "em visão geral quero colocar
// tudo que for possível... principalmente se o faturamento está caindo ou
// aumentando, comparado ao mês passado". Compara o faturamento do período
// selecionado no filtro do header com o período IMEDIATAMENTE ANTERIOR de
// MESMA DURAÇÃO (ver lib/periodoComparacao.js — mesma regra já usada em
// Performance de Anúncios/Visitas e Conversão, nunca uma definição nova).
// Quando falta faturamento em qualquer um dos dois lados (nenhum pedido no
// período, ou nenhum valor confirmado), a variação vem `null` com o motivo
// explícito — nunca uma % calculada a partir de um zero fabricado.
function evolucaoFaturamento({ faturamentoAtual, faturamentoAnterior, periodoAnterior }) {
  let variacaoValor = null;
  let variacaoPct = null;
  let tendencia = 'sem_dado';
  let motivoSemDado = null;

  if (faturamentoAtual === null || faturamentoAnterior === null) {
    motivoSemDado = 'Não há faturamento confirmado suficiente em um dos dois períodos para comparar.';
  } else {
    variacaoValor = round2(faturamentoAtual - faturamentoAnterior);
    variacaoPct = faturamentoAnterior !== 0 ? round2((variacaoValor / faturamentoAnterior) * 100) : null;
    if (variacaoPct === null && faturamentoAnterior === 0 && faturamentoAtual > 0) {
      // Sem base anterior (era 0) mas há faturamento agora — sobe, mas uma
      // % "infinita" não tem leitura útil: mostra a tendência sem número.
      tendencia = 'subindo';
    } else if (variacaoValor > 0) tendencia = 'subindo';
    else if (variacaoValor < 0) tendencia = 'caindo';
    else tendencia = 'estavel';
  }

  return {
    faturamentoAtual,
    faturamentoAnterior,
    variacaoValor,
    variacaoPct,
    tendencia,
    motivoSemDado,
    periodoAnterior: { desde: periodoAnterior.desdeStr, ate: periodoAnterior.ateStr },
  };
}

// ---------------- Fluxo de caixa ----------------
// "Recebimentos" aqui reaproveita os MESMOS pedidos elegíveis já buscados
// pra esta chamada (nunca uma segunda consulta) — é o mesmo dado mostrado
// na tela Recebimentos (lib/recebimentosMl.js), só somado.
function resumoRecebimentos(pedidos) {
  const recebimentos = pedidos.filter(elegivel).map(serializeRecebimento);
  let soma = 0, temValor = false, pendentes = 0;
  recebimentos.forEach((r) => {
    if (r.valorLiquidoEsperado === null) pendentes++;
    else { soma += r.valorLiquidoEsperado; temValor = true; }
  });
  return {
    quantidade: recebimentos.length,
    valorLiquidoEsperado: temValor ? round2(soma) : null,
    pendentes,
  };
}

async function fluxoDeCaixa({ empresaId, desdeStr, ateStr, pedidos }) {
  const [contasAPagar, contasAReceber, saldoBancario] = await Promise.all([
    resumoContasPagar({ empresaId, desde: desdeStr, ate: ateStr }),
    resumoContasReceber({ empresaId, desde: desdeStr, ate: ateStr }),
    // Mesma proteção já usada em lib/fluxoCaixa.js: uma falha aqui (schema
    // bancário ainda incompatível, etc.) nunca pode derrubar o resto deste
    // painel — cai pra "não informado", nunca inventa.
    saldoConsolidado(empresaId).catch((err) => {
      console.warn('[visao-geral] não foi possível obter o saldo bancário consolidado:', err && err.message);
      return null;
    }),
  ]);
  const recebimentosMl = resumoRecebimentos(pedidos);

  return {
    contasAPagar,
    contasAReceber,
    recebimentosMl,
    // saldoBancarioAtual = saldo consolidado (soma das contas bancárias com
    // saldo importado via extrato, ver lib/contasBancarias.js#saldoConsolidado
    // — MESMO número mostrado em Contas Bancárias/Fluxo de Caixa, nenhuma
    // fórmula nova). null quando nenhuma conta bancária tem saldo importado
    // ainda — nunca um valor inventado.
    saldoBancarioAtual: saldoBancario ? { valor: saldoBancario.valor, dataReferencia: saldoBancario.dataReferencia, motivo: null } : { valor: null, motivo: 'nenhuma_conta_bancaria_com_saldo_importado' },
    // saldoProjetado (fim do período à frente) precisa do cálculo dia-a-dia
    // completo de lib/fluxoCaixa.js#gerarFluxoDeCaixa (contas a pagar/
    // receber futuras dia a dia) — este resumo não duplica esse laço (pra
    // nunca virar uma segunda fórmula); por isso continua null aqui, com o
    // motivo correto (não é mais "sem saldo bancário cadastrado" — pode já
    // haver saldo bancário e mesmo assim a projeção dia-a-dia só existir na
    // tela Fluxo de Caixa).
    saldoProjetado: { valor: null, motivo: 'projecao_dia_a_dia_disponivel_na_tela_fluxo_de_caixa' },
  };
}

// ---------------- Conexões & empresas ----------------
async function conexoesEEmpresas(empresaId) {
  const [{ rows: totalEmpresasRows }, { rows: contasRows }, { rows: contasShopeeRows }] = await Promise.all([
    pool.query('SELECT count(*)::int AS total FROM empresas'),
    pool.query(
      `SELECT id, nickname, status, ultimo_erro, ultima_sincronizacao_em
       FROM ml_contas WHERE empresa_id = $1 ORDER BY created_at DESC`,
      [empresaId]
    ),
    pool.query(
      `SELECT id, shop_name, shopee_shop_id, status, ultimo_erro, ultima_sincronizacao_em
       FROM shopee_contas WHERE empresa_id = $1 ORDER BY created_at DESC`,
      [empresaId]
    ),
  ]);

  const ultimaSincronizacao = contasRows.reduce((max, c) => {
    if (!c.ultima_sincronizacao_em) return max;
    return !max || c.ultima_sincronizacao_em > max ? c.ultima_sincronizacao_em : max;
  }, null);

  let status = 'sem_conta';
  if (contasRows.some((c) => c.status === 'ativa')) status = 'ativa';
  else if (contasRows.some((c) => c.status === 'erro')) status = 'erro';
  else if (contasRows.length) status = 'desconectada';

  // Shopee (25/08/2026) — mesma lógica de status acima, agora com dado real
  // (shopee_contas). "ultimaSincronizacao" aqui fica sempre null: esta etapa
  // só conecta a loja (OAuth + renovação de token), pedidos da Shopee ainda
  // não são importados (fora do escopo pedido) — nunca inventamos essa data.
  let statusShopee = 'sem_conta';
  if (contasShopeeRows.some((c) => c.status === 'ativa')) statusShopee = 'ativa';
  else if (contasShopeeRows.some((c) => c.status === 'erro')) statusShopee = 'erro';
  else if (contasShopeeRows.length) statusShopee = 'desconectada';

  return {
    empresas: { total: totalEmpresasRows[0].total },
    mercadoLivre: {
      contasConectadas: contasRows.length,
      status,
      ultimaSincronizacao,
      contas: contasRows.map((c) => ({
        id: c.id, nickname: c.nickname, status: c.status, ultimoErro: c.ultimo_erro, ultimaSincronizacao: c.ultima_sincronizacao_em,
      })),
    },
    shopee: {
      contasConectadas: contasShopeeRows.length,
      status: statusShopee,
      contas: contasShopeeRows.map((c) => ({
        id: c.id, shopName: c.shop_name, shopId: String(c.shopee_shop_id), status: c.status, ultimoErro: c.ultimo_erro, ultimaSincronizacao: c.ultima_sincronizacao_em,
      })),
    },
  };
}

// ---------------- Alertas & IA (regras simples, sobre dado real) ----------------
async function gerarAlertas({ empresaId, pedidos, itens, fluxoCaixa, conexoes }) {
  const alertas = [];

  // 1) SKU sem custo cadastrado — a partir dos ITENS vendidos no período
  // (mesmo dado de Relatórios > Produtos: pr.custo IS NULL por causa do
  // LEFT JOIN, ou seja, nenhum produto cadastrado com esse SKU).
  const skusSemCusto = [...new Set(
    itens.filter((it) => it.sku && it.custoProduto === null).map((it) => it.sku)
  )];
  if (skusSemCusto.length === 1) {
    alertas.push({
      id: 'sku-sem-custo', tipo: 'sku_sem_custo', severidade: 'warning',
      titulo: 'SKU ' + skusSemCusto[0] + ' está sem custo cadastrado',
      descricao: 'Sem o custo cadastrado, a margem de contribuição das vendas desse SKU não pode ser calculada.',
      pagina: 'products',
    });
  } else if (skusSemCusto.length > 1) {
    const exemplos = skusSemCusto.slice(0, 3).join(', ') + (skusSemCusto.length > 3 ? '…' : '');
    alertas.push({
      id: 'sku-sem-custo', tipo: 'sku_sem_custo', severidade: 'warning',
      titulo: skusSemCusto.length + ' SKUs vendidos no período estão sem custo cadastrado',
      descricao: 'Incluindo ' + exemplos + '. Sem custo cadastrado, a margem dessas vendas não pode ser calculada.',
      pagina: 'products',
    });
  }

  // 2) Pedido sem custo, impedindo cálculo correto da margem (nível do
  // PEDIDO — buscarPedidosDoPeriodo já expõe custoProduto null quando
  // algum item dele não bate com nenhum SKU cadastrado).
  const pedidosSemCusto = pedidos.filter((p) => !p.cancelado && p.custoProduto === null);
  if (pedidosSemCusto.length) {
    alertas.push({
      id: 'pedido-sem-custo', tipo: 'pedido_sem_custo', severidade: 'warning',
      titulo: pedidosSemCusto.length === 1
        ? '1 pedido no período está sem custo de produto, impedindo o cálculo da margem'
        : pedidosSemCusto.length + ' pedidos no período estão sem custo de produto, impedindo o cálculo da margem',
      descricao: 'Cadastre o custo do(s) SKU(s) desses pedidos em Produtos para a margem de contribuição ser calculada.',
      pagina: 'orders',
    });
  }

  // 3) Margem negativa em alguma venda (pedido com cálculo completo e
  // resultado negativo — nunca inferido de um cálculo incompleto).
  const margemNegativa = pedidos.filter((p) => !p.cancelado && p.calculoCompleto && p.margemContribuicao < 0);
  if (margemNegativa.length) {
    alertas.push({
      id: 'margem-negativa', tipo: 'margem_negativa', severidade: 'danger',
      titulo: margemNegativa.length === 1
        ? '1 venda no período com margem de contribuição negativa'
        : margemNegativa.length + ' vendas no período com margem de contribuição negativa',
      descricao: 'Taxas, frete, imposto e custo somados superaram o valor da venda em pelo menos um pedido.',
      pagina: 'orders',
    });
  }

  // 4) Erro de sincronização do Mercado Livre (mesmo status já mostrado em
  // Marketplaces — ml_contas.status/ultimo_erro).
  (conexoes.mercadoLivre.contas || []).filter((c) => c.status === 'erro').forEach((c) => {
    alertas.push({
      id: 'ml-sync-erro-' + c.id, tipo: 'ml_sync_erro', severidade: 'danger',
      titulo: 'Conta do Mercado Livre "' + (c.nickname || ('ID ' + c.id)) + '" está com erro de sincronização',
      descricao: c.ultimoErro || 'Reconecte a conta em Marketplaces para corrigir.',
      pagina: 'marketplaces',
    });
  });

  // 5) Conta a pagar vencida (mesmo "vencidas" já mostrado em Contas a
  // Pagar — saldo em aberto, independente do período, ver
  // lib/contasPagar.js/resumoContasPagar).
  if (fluxoCaixa.contasAPagar.vencidas > 0) {
    alertas.push({
      id: 'contas-pagar-vencidas', tipo: 'contas_pagar_vencidas', severidade: 'danger',
      titulo: 'Contas a pagar vencidas',
      descricao: formatMoney(fluxoCaixa.contasAPagar.vencidas) + ' em aberto, já vencido(s).',
      pagina: 'payable',
    });
  }

  // 6) Recebimento (conta a receber) atrasado — mesmo "atrasado" já
  // mostrado em Contas a Receber (lib/contasReceber.js/resumoContasReceber).
  // A tela "Recebimentos" (repasses do Mercado Livre) ainda não tem uma
  // data prevista real (ver lib/recebimentosMl.js) — por isso "atraso" só
  // existe hoje no lançamento manual de Contas a Receber.
  if (fluxoCaixa.contasAReceber.atrasado > 0) {
    alertas.push({
      id: 'contas-receber-atrasadas', tipo: 'recebimento_atrasado', severidade: 'warning',
      titulo: 'Recebimentos atrasados',
      descricao: formatMoney(fluxoCaixa.contasAReceber.atrasado) + ' em contas a receber com previsão já vencida.',
      pagina: 'receivable',
    });
  }

  // 7) Estoque zerado ou muito baixo — só itens JÁ sincronizados
  // (pendente = FALSE e quantidade não nula — nunca alerta em cima de um
  // dado que a API do Mercado Livre não retornou).
  const { rows: estoqueBaixo } = await pool.query(
    `SELECT tipo, titulo, sku, quantidade FROM ml_estoque_itens
     WHERE empresa_id = $1 AND pendente = FALSE AND quantidade IS NOT NULL AND quantidade <= $2`,
    [empresaId, ESTOQUE_BAIXO_LIMITE]
  );
  const zerados = estoqueBaixo.filter((r) => Number(r.quantidade) === 0);
  const baixos = estoqueBaixo.filter((r) => Number(r.quantidade) > 0);
  if (zerados.length) {
    alertas.push({
      id: 'estoque-zerado', tipo: 'estoque_zerado', severidade: 'danger',
      titulo: zerados.length === 1 ? '1 anúncio com estoque zerado' : zerados.length + ' anúncios com estoque zerado',
      descricao: 'Estoque sincronizado do Mercado Livre mostra 0 unidade(s) disponível(is).',
      pagina: 'stock',
    });
  }
  if (baixos.length) {
    alertas.push({
      id: 'estoque-baixo', tipo: 'estoque_baixo', severidade: 'warning',
      titulo: baixos.length === 1 ? '1 anúncio com estoque muito baixo' : baixos.length + ' anúncios com estoque muito baixo',
      descricao: 'Estoque sincronizado do Mercado Livre com ' + ESTOQUE_BAIXO_LIMITE + ' unidades ou menos.',
      pagina: 'stock',
    });
  }

  const ordemSeveridade = { danger: 0, warning: 1, info: 2 };
  alertas.sort((a, b) => ordemSeveridade[a.severidade] - ordemSeveridade[b.severidade]);
  return alertas;
}

// ---------------- Função principal ----------------
async function painelVisaoGeral({ empresaId, periodoChave, desde: desdeQuery, ate: ateQuery }) {
  const periodoCalc = calcularPeriodo(periodoChave, { desde: desdeQuery, ate: ateQuery });
  const { desde: desdeStr, ate: ateStr } = periodoParaDatasBRT(periodoCalc);

  const [{ pedidos }, { itens }, conexoes] = await Promise.all([
    buscarPedidosDoPeriodo({ empresaId, desde: periodoCalc.desde, ate: periodoCalc.ate }),
    buscarItensDoPeriodo({ empresaId, desde: periodoCalc.desde, ate: periodoCalc.ate }),
    conexoesEEmpresas(empresaId),
  ]);

  const canalResultado = porCanal(pedidos);
  const fluxoCaixa = await fluxoDeCaixa({ empresaId, desdeStr, ateStr, pedidos });
  const alertas = await gerarAlertas({ empresaId, pedidos, itens, fluxoCaixa, conexoes });

  // Faturamento vs. período anterior (20/09/2026 — ver evolucaoFaturamento
  // acima). Busca só os PEDIDOS do período anterior (mesma fonte única de
  // sempre) — nunca uma segunda forma de somar faturamento.
  const periodoAnteriorCalc = periodoAnteriorEquivalente({ desde: periodoCalc.desde, ate: periodoCalc.ate });
  const { desde: periodoAnteriorDesdeStr, ate: periodoAnteriorAteStr } = periodoParaDatasBRT(periodoAnteriorCalc);
  const { pedidos: pedidosPeriodoAnterior } = await buscarPedidosDoPeriodo({
    empresaId, desde: periodoAnteriorCalc.desde, ate: periodoAnteriorCalc.ate,
  });
  const faturamentoEvolucao = evolucaoFaturamento({
    faturamentoAtual: canalResultado.totalFaturamento,
    faturamentoAnterior: resumirPeriodo(pedidosPeriodoAnterior).faturamento.valor,
    periodoAnterior: { desdeStr: periodoAnteriorDesdeStr, ateStr: periodoAnteriorAteStr },
  });

  // Radar da IA — nunca quebra o resto da Visão Geral se algo falhar aqui
  // (ex.: tabela ainda não migrada num banco muito antigo); some da
  // resposta com um aviso claro em vez de derrubar a tela inteira.
  let radar = null, radarError = null;
  try {
    const { obterRadarParaEmpresa } = require('./ia/radar');
    radar = await obterRadarParaEmpresa(empresaId);
  } catch (e) {
    radarError = 'Não foi possível carregar o Radar da IA agora.';
    console.error('[visão geral] falha ao carregar o Radar da IA: ' + e.message);
  }

  // Resumo dos Agentes de IA (20/09/2026, pedido explícito do usuário: "em
  // visão geral quero colocar tudo que for possível... os agentes ia,
  // resumos") — reaproveita EXATAMENTE lib/ia/agentesResumo.js#obterResumoHub,
  // a MESMA função que já alimenta o hub "Agentes de IA" (kpis, pendentes e
  // sugestões novas de hoje por agente) — nenhum cálculo novo. Mesmo
  // require() lazy (dentro da função) e mesma proteção contra falha do
  // `radar` logo acima, e pelo mesmo motivo: agentesResumo.js também
  // depende de lib/ia/radar.js, então um require() no topo deste arquivo
  // fecharia a mesma dependência circular já documentada ali.
  let agentesIa = null, agentesIaError = null;
  try {
    const { obterResumoHub } = require('./ia/agentesResumo');
    agentesIa = await obterResumoHub(empresaId);
  } catch (e) {
    agentesIaError = 'Não foi possível carregar o resumo dos Agentes de IA agora.';
    console.error('[visão geral] falha ao carregar o resumo dos Agentes de IA: ' + e.message);
  }

  // Projeção de vendas do MÊS CORRENTE (26/09/2026, pedido explícito do
  // usuário — ver lib/ia/projecaoVendas.js) — sempre calculada pro mês
  // atual (independente do período escolhido no filtro da tela, que pode
  // ser "Hoje"/"7 dias"/etc.), porque é isso que o usuário pediu: "projeção
  // de vendas dentro daquele mes". Mesmo padrão de nunca quebrar a Visão
  // Geral inteira (radar/agentesIa acima) se o cálculo falhar.
  let projecaoVendas = null, projecaoVendasError = null;
  try {
    const { projetarVendasDoMes } = require('./ia/projecaoVendas');
    projecaoVendas = await projetarVendasDoMes({ empresaId });
  } catch (e) {
    projecaoVendasError = 'Não foi possível calcular a projeção de vendas do mês agora.';
    console.error('[visão geral] falha ao calcular projeção de vendas: ' + e.message);
  }

  // Clientes Novos e Recorrentes (26/09/2026, pedido explícito do usuário —
  // ver lib/clientesNovosRecorrentes.js) — usa o MESMO período escolhido no
  // filtro da tela (diferente da projeção de vendas acima, que é sempre o
  // mês corrente). Mesmo padrão de nunca quebrar a Visão Geral se falhar.
  let clientesNovosRecorrentes = null, clientesNovosRecorrentesError = null;
  try {
    const { analisarClientesNovosRecorrentes } = require('./clientesNovosRecorrentes');
    clientesNovosRecorrentes = await analisarClientesNovosRecorrentes({
      empresaId, desde: periodoCalc.desde, ate: periodoCalc.ate,
    });
  } catch (e) {
    clientesNovosRecorrentesError = 'Não foi possível calcular clientes novos/recorrentes agora.';
    console.error('[visão geral] falha ao calcular clientes novos/recorrentes: ' + e.message);
  }

  return {
    periodo: { chave: periodoCalc.chave, label: periodoCalc.label, desde: periodoCalc.desde, ate: periodoCalc.ate },
    porCanal: canalResultado,
    faturamentoEvolucao,
    fluxoCaixa,
    conexoes,
    alertas,
    radar,
    radarError,
    agentesIa,
    agentesIaError,
    projecaoVendas,
    projecaoVendasError,
    clientesNovosRecorrentes,
    clientesNovosRecorrentesError,
  };
}

module.exports = {
  painelVisaoGeral,
  identificarCanal,
  porCanal,
  evolucaoFaturamento,
  resumoRecebimentos,
  fluxoDeCaixa,
  conexoesEEmpresas,
  gerarAlertas,
  formatMoney,
  ESTOQUE_BAIXO_LIMITE,
};
